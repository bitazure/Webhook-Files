<?php
ob_start();
session_start();
include("member/includes/connection.php");
include("member/includes/functions.php");
//isAdmin();

$qry=mysqli_query($conn,"select * from register where id='".base64_decode($_REQUEST['id'])."'");
$obj=mysqli_fetch_object($qry);
$lid=base64_decode($_REQUEST['id']);
//$ssss=SMSSMS($lid);

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Main CSS-->
<title><?php echo TITLE; ?> </title>
<link rel="shortcut icon" href="images/favicon.ico" />
<link rel="stylesheet" type="text/css" href="css/main.css">
<!--<link href="css/bootstrap.css" rel="stylesheet">-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- Font-icon css-->
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body class="app sidebar-mini rtl">
<!-- Navbar-->
<?php include("top_header.php"); ?>
<!-- Sidebar menu-->
<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar">
   <?php include("main_menu.php"); ?>
</aside>
<main class="app-content">
  <div class="row">
    <div class="col-md-12">
      <div class="tile">
        <h1 class="tile-body">Payment Success</h1>
        <div class="row">
        	<div class="col-lg-12">
              <div class="tabular">
                                  <?php
	function base64UrlEncode($text)
	{
		return str_replace(
			['+', '/', '='],
			['-', '_', ''],
			base64_encode($text)
		);
	}
	 $jwt =$_REQUEST["token"];		 
	 if($jwt== ""){
		 echo "Invalid Page";
	 }
	 else{		 
	 $tokenParts = explode('.', $jwt);
	 $header = base64_decode($tokenParts[0]);
	 $payload = base64_decode($tokenParts[1]);
	 $signatureProvided = $tokenParts[2];		
	 
	 $base64UrlHeader = base64UrlEncode($header);
	 $base64UrlPayload = base64UrlEncode($payload);
	 $secret = "8N3IY8CQaUNv5IrdvC1Qkg==";
	 $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $secret, true);
	 $base64UrlSignature = base64UrlEncode($signature);
	 
	 if($signatureProvided == $base64UrlSignature){
		echo "Transaction Failed";
		$selQry=mysqli_query($conn,"delete  from pin_request where trxtransaction_ID='".$_REQUEST["transactionId"]."'");
	 }
	 else{
		 echo "InValid User";			 
	 }
	}
	?>
                               </div>
          	</div>
        </div>
      </div>
    </div>
  </div>
</main>
 <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Data table plugin-->
    <script type="text/javascript" src="js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
<!-- Page specific javascripts-->
</body>
</html>
