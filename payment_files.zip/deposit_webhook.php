<?php
include("init_payment.php");
$jwt = $_REQUEST["data"];
if ($jwt == "") {
	echo "Invalid Page";
} else {
	if (validateResult($jwt)) {
	  $response = getResponseResult($jwt);
	  echo $response->referenceNo; // Our ID in our Database
	  echo $response->transactionId; // your ID in your Database
	  echo $response->transactionhash; // blockchain hash
		//do logic here
	} else {
	}
}
