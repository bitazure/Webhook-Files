<?php
include("init_payment.php");
$jwt = $_REQUEST["data"];
if ($jwt == "") {
	echo "Invalid Page";
} else {
	if (validateResult($jwt)) {
		//do logic here
	} else {
	}
}
