<?php
 
ob_start();

session_start();

include("member/includes/connection.php");

include("member/includes/functions.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);
require '/home2/tamwaosi/public_html/PHPMailer/src/Exception.php';
require '/home2/tamwaosi/public_html/PHPMailer/src/PHPMailer.php';
require '/home2/tamwaosi/public_html/PHPMailer/src/SMTP.php';
  
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Crowd n Club</title>
<link rel="shortcut icon" href="favicon.ico" />
<!-- Style css -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<!-- Bootstrap css -->
<link href="css/bootstrap.css" rel="stylesheet" />
<link href="css/animate.min.css" rel="stylesheet" type="text/css"  />
<link href="css/slick.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<link href="css/font-awesome.min.css" rel="stylesheet" />
<!--<link href="css/navigation-styles.css" rel="stylesheet" type="text/css">
-->
<link href="favicon.ico">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script src="member/js/country.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/jquery-2.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script>
$(window).scroll(function() {
  var sticky = $('.mobile-menu'),
    scroll = $(window).scrollTop();
   
  if (scroll >= 40) { 
    sticky.addClass('fixed'); }
  else { 
   sticky.removeClass('fixed');

}
});
</script>



</head>
<body>

<div class="main">
  <div class="bg_white">
    <header class="mobile-menu">
      <div class="container">
        <div class="col-lg-3 col-md-3 col-sm-2 col-xs-12">
          <div class="row"> <a href="index.php" class="logo" title="Crowd n Club"><img src="images/logo.png" class="img-responsive" alt="Crowd n Club" /></a>
            <div class="mob_menu_btns pull-right visible-xs">
              <button type="button" class="navbar-toggle collapsed mob_menu_btn" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false"><span class="visible-xs">menu</span></button>
            </div>
          </div>
        </div>
        <div class="col-lg-9 col-md-9 col-sm-10 col-xs-12">
          <div class="row">
            <nav class="navbar navbar-default">
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  <li><a href="index.php">Home</a></li>
                  <li><a href="about-us.php">Crowd n Club</a></li>
                  <li><a href="markets.php">Markets</a></li>
                  <li><a href="crowd-funding.php">Crowd Funding</a></li>
                  <li><a href="faq.php">FAQ</a></li>
                  <li><a href="contact.php">Contact Us</a></li>
                  <li class="active"><a href="/member" target="_blank">Login</a></li>
                </ul>
                <div class="clearfix"></div>
              </div>
            </nav>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>
      <div class="clearfix"></div>
    </header> 
 </div>
 
                    
 
 <div class="clearfix"></div>
  
    </div>
</div>

 <div class="clearfix"></div>
  
    <div class="inner-banner-about">
  		<div class="container">
            <div class="col-lg-12">
                <h1>Blockchain decentralized and anonymous platform.</h1>
            </div>
        </div>
  </div>


<div class="inner-content-bg">
	<div class="container">
        	<div class="col-lg-12 col-xs-12">
            
            <h1>Registration Details</h1>
            <div class="uline"></div>
            
            <div class="row">
            	<div class="col-lg-6 col-xs-12">
              	<div class="form-group">

				  <?php
	function base64UrlEncode($text)
	{
		return str_replace(
			['+', '/', '='],
			['-', '_', ''],
			base64_encode($text)
		);
	}
	 $jwt =$_REQUEST["token"];		 
	 if($jwt== ""){
		 echo "Invalid Page";
	 }
	 else{		 
	 $tokenParts = explode('.', $jwt);
	 $header = base64_decode($tokenParts[0]);
	 $payload = base64_decode($tokenParts[1]);
	 $signatureProvided = $tokenParts[2];		
	 
	 $base64UrlHeader = base64UrlEncode($header);
	 $base64UrlPayload = base64UrlEncode($payload);
	 $secret = "8N3IY8CQaUNv5IrdvC1Qkg==";
	 $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $secret, true);
	 $base64UrlSignature = base64UrlEncode($signature);
	 
	 if($signatureProvided == $base64UrlSignature){
		 $selQry=mysqli_query($conn,"select * from member_register where trxtransaction_ID='".$_REQUEST["transactionId"]."'");
		 $selObj=mysqli_fetch_object($selQry);
		 if($selObj->Status!=1)
		 {
			 $uppTrx=mysqli_query($conn,"update member_register set Status=1,trxrefference_No='".$_REQUEST["transactionHash"]."' where trxtransaction_ID='".$_REQUEST["transactionId"]."'");
 			 global $flag;
			$flag=(bool)true;
			if($flag)
			{
				global $idno;
				checkid();
			}
			
			$TP = substr(str_shuffle('0123456789'), 0, 6);
			 
			$qry=mysqli_query($conn,"insert into register set  mname='".$selObj->CustomerName."' ,mobile='".$selObj->CustomerPhone."',email='".$selObj->CustomerEmail."' ,mem_id='$idno' ,pass='$TP',T_Pass='$TP'  ,d_id='".$selObj->d_id."' ,product_amount='".$selObj->Amount."' ,jdate='".date("Y-m-d")."' ,status=0");
	  		
			 
				$lid=mysqli_insert_id($conn);
				
				if($lid!=0)
				{
					$reffercount=mysqli_query($conn,"update register set d_count=d_count+1  where mem_id='".$selObj->d_id."'");
				
					$qry2=mysqli_query($conn,"insert into invest_amount set   mem_id='$idno'  ,Amount='".$selObj->Amount."' ,jdate='".date("Y-m-d")."'");
					 
					$DR=$selObj->Amount*40/100;
					$am=$selObj->Amount;
					$sid=$selObj->d_id;
					$RX=$selObj->Amount*10/100;
					$TRX=($selObj->Amount*10/100)/5;
					$updownline=mysqli_query($conn,"update register set D_TRX=D_TRX+$RX where mem_id='".$idno."'");
					 
					$drQry=mysqli_query($conn,"select * from register where mem_id='".$selObj->d_id."'");
					$drobj=mysqli_fetch_object($drQry);
					if($drobj->d_count==3)
					{
						$drsponQry=mysqli_query($conn,"select * from register where mem_id='".$selObj->d_id."'");
						$drsponobj=mysqli_fetch_object($drsponQry);
						$drsponQry1=mysqli_query($conn,"select * from register where mem_id='".$drsponobj->d_id."'");
						$drsponobj1=mysqli_fetch_object($drsponQry1);
						$upppp222=mysqli_query($conn,"update register set reffer=reffer+$DR, Amount=Amount+$DR where mem_id='".$drsponobj1->d_id."'");


					}
					else if($drobj->d_count==6)
					{
						$drsponQry=mysqli_query($conn,"select * from register where mem_id='".$selObj->d_id."'");
						$drsponobj=mysqli_fetch_object($drsponQry);
						$drsponQry1=mysqli_query($conn,"select * from register where mem_id='".$drsponobj->d_id."'");
						$drsponobj1=mysqli_fetch_object($drsponQry1);
						$drsponQry2=mysqli_query($conn,"select * from register where mem_id='".$drsponobj1->d_id."'");
						$drsponobj2=mysqli_fetch_object($drsponQry2);
						$upppp222=mysqli_query($conn,"update register set reffer=reffer+$DR, Amount=Amount+$DR where mem_id='".$drsponobj2->d_id."'");

					}
					else if($drobj->d_count==9)
					{
						$drsponQry=mysqli_query($conn,"select * from register where mem_id='".$selObj->d_id."'");
						$drsponobj=mysqli_fetch_object($drsponQry);
						$drsponQry1=mysqli_query($conn,"select * from register where mem_id='".$drsponobj->d_id."'");
						$drsponobj1=mysqli_fetch_object($drsponQry1);
						$drsponQry2=mysqli_query($conn,"select * from register where mem_id='".$drsponobj1->d_id."'");
						$drsponobj2=mysqli_fetch_object($drsponQry2);
						$drsponQry3=mysqli_query($conn,"select * from register where mem_id='".$drsponobj2->d_id."'");
						$drsponobj3=mysqli_fetch_object($drsponQry3);
						$upppp222=mysqli_query($conn,"update register set reffer=reffer+$DR, Amount=Amount+$DR where mem_id='".$drsponobj3->d_id."'");

						
					}
					else if($drobj->d_count==12)
					{
						$drsponQry=mysqli_query($conn,"select * from register where mem_id='".$selObj->d_id."'");
						$drsponobj=mysqli_fetch_object($drsponQry);
						$drsponQry1=mysqli_query($conn,"select * from register where mem_id='".$drsponobj->d_id."'");
						$drsponobj1=mysqli_fetch_object($drsponQry1);
						$drsponQry2=mysqli_query($conn,"select * from register where mem_id='".$drsponobj1->d_id."'");
						$drsponobj2=mysqli_fetch_object($drsponQry2);
						$drsponQry3=mysqli_query($conn,"select * from register where mem_id='".$drsponobj2->d_id."'");
						$drsponobj3=mysqli_fetch_object($drsponQry3);
						$drsponQry4=mysqli_query($conn,"select * from register where mem_id='".$drsponobj3->d_id."'");
						$drsponobj4=mysqli_fetch_object($drsponQry4);
						$upppp222=mysqli_query($conn,"update register set reffer=reffer+$DR, Amount=Amount+$DR where mem_id='".$drsponobj4->d_id."'");
						
					}
					else if($drobj->d_count==15)
					{
						$drsponQry=mysqli_query($conn,"select * from register where mem_id='".$selObj->d_id."'");
						$drsponobj=mysqli_fetch_object($drsponQry);
						$drsponQry1=mysqli_query($conn,"select * from register where mem_id='".$drsponobj->d_id."'");
						$drsponobj1=mysqli_fetch_object($drsponQry1);
						$drsponQry2=mysqli_query($conn,"select * from register where mem_id='".$drsponobj1->d_id."'");
						$drsponobj2=mysqli_fetch_object($drsponQry2);
						$drsponQry3=mysqli_query($conn,"select * from register where mem_id='".$drsponobj2->d_id."'");
						$drsponobj3=mysqli_fetch_object($drsponQry3);
						$drsponQry4=mysqli_query($conn,"select * from register where mem_id='".$drsponobj3->d_id."'");
						$drsponobj4=mysqli_fetch_object($drsponQry4);
						$drsponQry5=mysqli_query($conn,"select * from register where mem_id='".$drsponobj4->d_id."'");
						$drsponobj5=mysqli_fetch_object($drsponQry5);
						$upppp222=mysqli_query($conn,"update register set reffer=reffer+$DR, Amount=Amount+$DR where mem_id='".$drsponobj5->d_id."'");
						
					}
					else if($drobj->d_count==18)
					{
						$drsponQry=mysqli_query($conn,"select * from register where mem_id='".$selObj->d_id."'");
						$drsponobj=mysqli_fetch_object($drsponQry);
						$drsponQry1=mysqli_query($conn,"select * from register where mem_id='".$drsponobj->d_id."'");
						$drsponobj1=mysqli_fetch_object($drsponQry1);
						$drsponQry2=mysqli_query($conn,"select * from register where mem_id='".$drsponobj1->d_id."'");
						$drsponobj2=mysqli_fetch_object($drsponQry2);
						$drsponQry3=mysqli_query($conn,"select * from register where mem_id='".$drsponobj2->d_id."'");
						$drsponobj3=mysqli_fetch_object($drsponQry3);
						$drsponQry4=mysqli_query($conn,"select * from register where mem_id='".$drsponobj3->d_id."'");
						$drsponobj4=mysqli_fetch_object($drsponQry4);
						$drsponQry5=mysqli_query($conn,"select * from register where mem_id='".$drsponobj4->d_id."'");
						$drsponobj5=mysqli_fetch_object($drsponQry5);
						$drsponQry6=mysqli_query($conn,"select * from register where mem_id='".$drsponobj5->d_id."'");
						$drsponobj6=mysqli_fetch_object($drsponQry6);
						$upppp222=mysqli_query($conn,"update register set reffer=reffer+$DR, Amount=Amount+$DR where mem_id='".$drsponobj6->d_id."'");
						
					}
					else if($drobj->d_count==21)
					{
						$drsponQry=mysqli_query($conn,"select * from register where mem_id='".$selObj->d_id."'");
						$drsponobj=mysqli_fetch_object($drsponQry);
						$drsponQry1=mysqli_query($conn,"select * from register where mem_id='".$drsponobj->d_id."'");
						$drsponobj1=mysqli_fetch_object($drsponQry1);
						$drsponQry2=mysqli_query($conn,"select * from register where mem_id='".$drsponobj1->d_id."'");
						$drsponobj2=mysqli_fetch_object($drsponQry2);
						$drsponQry3=mysqli_query($conn,"select * from register where mem_id='".$drsponobj2->d_id."'");
						$drsponobj3=mysqli_fetch_object($drsponQry3);
						$drsponQry4=mysqli_query($conn,"select * from register where mem_id='".$drsponobj3->d_id."'");
						$drsponobj4=mysqli_fetch_object($drsponQry4);
						$drsponQry5=mysqli_query($conn,"select * from register where mem_id='".$drsponobj4->d_id."'");
						$drsponobj5=mysqli_fetch_object($drsponQry5);
						$drsponQry6=mysqli_query($conn,"select * from register where mem_id='".$drsponobj5->d_id."'");
						$drsponobj6=mysqli_fetch_object($drsponQry6);
						$drsponQry7=mysqli_query($conn,"select * from register where mem_id='".$drsponobj6->d_id."'");
						$drsponobj7=mysqli_fetch_object($drsponQry7);
						$upppp222=mysqli_query($conn,"update register set reffer=reffer+$DR, Amount=Amount+$DR where mem_id='".$drsponobj6->d_id."'");
						
					}
					else if($drobj->d_count==24)
					{
						
					}
					else if($drobj->d_count==27)
					{
						
					}
					else if($drobj->d_count==30)
					{
						
					}
					else if($drobj->d_count==33)
					{
						
					}
					else
					{
						$upppp222=mysqli_query($conn,"update register set reffer=reffer+$DR, Amount=Amount+$DR where mem_id='".$selObj->d_id."'");

					}

						

						$fff=level1($sid,$am);
						$trxD=$TRX;
						$mem_id=$idno;
						$ffgggf=downline1($sid,$mem_id,$trxD);
					 
					//$ffff=WelcomeMail($lid);
				}
			// $uptrxEPIN=mysqli_query($conn,"update register set EPIN_Amount=EPIN_Amount+$trxAmount where mem_id='".$selObj->mem_id."'");
		 }



		 					$wlc=mysqli_query($conn,"select * from register where  mem_id='".$idno."'");
							  $wwobj=mysqli_fetch_object($wlc);
							  $wlcs=mysqli_query($conn,"select * from register where  mem_id='".$wwobj->d_id."'");
							  $swwobj=mysqli_fetch_object($wlcs);
							  $email_to =$wwobj->email;
							  $mail = new PHPMailer();
							  $mail->IsSMTP();
							  $mail->SMTPDebug = 2;
							  $mail->Mailer = "smtp";
							  $mail->Host = "mail.crowdnclub.com";
							  $mail->SMTPAuth = true;
							  $mail->SMTPSecure = "ssl"; //ssl or tls
							  $mail->Port = 465; //set smtp port for the gmail
							  $mail->Username = "admin@crowdnclub.com"; //yourname@yourdomain
							  $mail->Password = "Qwertyuiop12#$"; //password
							  
							  $mail->AddAddress($email_to); //to:
							  //subject
							  $mail->Subject = "Login Details";
							  //html body
							  $lid= base64_encode($lid);
							  $mail->IsHTML(true);
							  $mail->Body = '<div style="padding:35px; background:#ebebeb; width:85%; margin:auto">
							  <div style="padding:25px; background:#fff;">
							  <div align="left" style="background:#161f36;"><img src="https://'.$_SERVER['SERVER_NAME'].'/images/logo.png"></div>
							  <br>
							  <h2 style="color:#aa1721; font-family:Arial, Helvetica, sans-serif;">Hi '.$wwobj->mname.',</h2> 
							  <p style="color:#212529; font-size:15px; line-height:24px; font-family:Arial, Helvetica, sans-serif;">Welcome to Crowd N Club. We are excited to have you as part of our esteemed   membership. As a member of Crowd N Club, you will enjoy many unique benefits and privileges. Please visit us at www.crowdnclub.com for more membership details.</p><br>
							   <p>We look forward to seeing at all our Login Details!.</p> 
										 <div style="color:#212529; font-size:15px; line-height:24px; font-family:Arial, Helvetica, sans-serif;">
											  <table width="60%" cellpadding="1" cellspacing="1" border="0">
											  <tbody>
												<tr>
												  <td width="50%" bgcolor="#e0dfdf" style="padding:5px 10px;"><strong>Member ID</strong></td>
												  <td width="50%" bgcolor="#eae9e9" style="padding:5px 10px;">'.$wwobj->mem_id.'</td>
												</tr>
												<tr>
												  <td bgcolor="#e0dfdf" style="padding:5px 10px;"><strong>Password</strong></td>
												  <td bgcolor="#eae9e9" style="padding:5px 10px;">'.$wwobj->pass.'</td>
												</tr>
												<tr>
												  <td bgcolor="#e0dfdf" style="padding:5px 10px;"><strong>Transaction Password</strong></td>
												  <td bgcolor="#eae9e9" style="padding:5px 10px;">'.$wwobj->T_Pass.'</td>
												</tr>
												 
											  </tbody>
											</table>
										  </div>
										  
										  <div class="clearfix"></div>
										 
										  
										  <br />
										  <p style="color:#212529; font-size:15px; line-height:24px; font-family:Arial, Helvetica, sans-serif; font-weight:bold;">Sincerely,<br /> 
										  Team Crowd N Club</p>
										   
									  </div>
								 
								  </div>';
							   $mail->From = "admin@crowdnclub.com";
							  $mail->FromName = "Crowd N Club";
							  $mail->wordWrap = 50;
							  //send
							  $mail->Send();
							  
							  header("location:registration-details.php?id=$lid");
		 ?>


 

		 <?php

		//echo "Transaction ID : ".$_REQUEST["transactionId"]."<br>";
		//echo "Transaction Hash : ".$_REQUEST["transactionHash"]."<br>";
		//echo "Reference No : ".$_REQUEST["referenceNo"]."<br>";
		//echo "Member ID : ".$idno."<br>";
		//echo "Password  : ".$TP."<br>";
		//echo "Transaction Password : ".$TP."<br>";
		//echo "Transaction Successfull";
	 }
	 else{
		// echo $signatureProvided;
		// echo "<br/>";
		// echo $base64UrlSignature;
		 echo "InValid User";			 
	 }
	}
	?>
                    
               
    						</div>
               </div>
             </div>
           
          	</div>
        </div>
</div>

  

  
<div class="copyright">
    	<div class="container">
            <div class="col-lg-5 col-xs-12">
             <p>Crowd n Club has more than 10 years of experience in financial markets. <a href="about-us.php"><strong>Read more</strong> <i class="fa fa-angle-right" aria-hidden="true"></i></a></p>
            </div>
            <div class="col-lg-4 col-xs-12">
              <div class="row">
              	<div class="col-lg-6">
                	<ul> 
                        <li><a href="#">How to buy?</a></li>
                        <li><a href="#">Coin Overview</a></li>
                        <li><a href="#">News</a></li>
                    </ul>
                </div>
                <div class="col-lg-4">
                	<ul>
                        <li><a href="#">Terms of use</a></li>
                        <li><a href="#">Disclaimer</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
            <div class="col-lg-3 col-xs-12">
              <div align="payment">
                <div class="ico-payment"><img src="images/ftr-logo.png" class="img-responsive"></div>
                <ul class="socialmedia">
                	<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                </ul>
                <br>
                <div class="clearfix"></div>
              </div>
            </div>
            <div class="clearfix"></div>
            
            <div class="ftrline"></div>
                <div class="col-lg-12">
                    <p>&copy; Copyright 2022 Crowd n Club. All rights reserved.</p>
                </div>
            
            <div class="clearfix"></div>
        </div>
      </div>
</div>



<script type='text/javascript' src="js/jquery.mobile.customized.min.js"></script>
<!--[if !IE]>--><script  src="js/wow.min.js"></script><!-- <![endif]-->
<script>window.jQuery || document.write('<script src="js/jquery-2.1.1.min.js"><\/script>')</script>
<script src="js/modernizr.js"></script>

<script>
var selectIds = $('#panel1,#panel2,#panel3,#panel4,#panel5,#panel6');
$(function ($) {
    selectIds.on('show.bs.collapse hidden.bs.collapse', function () {
        $(this).prev().find('.glyphicon').toggleClass('glyphicon-plus glyphicon-minus');
    })
});
</script>

<script src="js/jquery.validate.min.js"></script>
 <!-- USER DEFINE SCRIPT -->
        <script>

                                            // =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
                                            // Custom Validation Start

                                            // Custom method add for pattern validation
                                            $.validator.addMethod("regex", function (value, element, regexpr) {
                                                return regexpr.test(value);
                                            }, "");

                                            $("#register").validate({
                                                highlight: function (label) {
                                                    $(label).closest('.form-group').removeClass('has-success').addClass('has-error');
                                                },
                                                success: function (label) {
                                                    $(label).closest('.form-group').removeClass('has-error');
                                                    label.remove();
                                                },

                                               
                                                 rules: {
                                                        PIN:{required: true},lastName:{required: true, regex: /^[a-zA-Z ]+$/},country:{required: true},state:{required: true},cityName:{required: true, regex: /^[a-zA-Z ]+$/},emailAddress:{required: true, email: true},mobileNumber:{required: true, number: true, min: 1000000000, max: 9999999999},terms:{required: true},                                                },
                                                messages: {
                                                        PIN:{required: "Please select PIN"},lastName:{required: "Please enter Name", regex: "Please enter valid Name"},country:{required: "Please select country"},state:{required: "Please select state"},cityName:{required: "Please enter city", regex: "Please enter valid city name"},emailAddress:{required: "Please enter email address", email: "Please enter valid email address"},mobileNumber:{required: "Please enter mobile number", min: "Please enter valid mobile number", max: "Please enter valid mobile number"},terms:{required: "Please select the checkbox"},                                                }
                                            });

                                            // Custom Validation End

                                            function validatePageData(dbAction) {
                                                document.register.dbAction.value = dbAction;
                                            }

                                            // Validate Sponsor
                                         function checkAvailability() {
											$("#loaderIcon").show();
											jQuery.ajax({
											url: "check_availability22.php",
											data:'username='+$("#mobileNumber").val(),
											type: "POST",
											success:function(data){
												$("#user-availability-status").html(data);
												$("#loaderIcon").hide();
											},
											error:function (){}
											});
										}
                                            // Validate Username
                                            function validateUserName() {
                                                var loginData = document.register.userName.value;
                                                $.ajax({
                                                    type: "POST",
                                                    url: 'code/ajaxValidate.php',
                                                    data: {
                                                        loginName: loginData,
                                                        dbAction: 9813
                                                    },
                                                    success: function (data) {
                                                        var msg = data.split("#");
                                                        if (msg[0] == '1') {
                                                            $("#userNameDiv").addClass("has-error");
                                                            $('#userNameMsg').css('display', 'block');
                                                            $('#userNameMsg').html(msg[1]);
                                                        } else if (msg[0] == '0') {
                                                            $('#userNameMsg').html('');
                                                        }
                                                        //                      $('#replicatedLink').html('www.robootraders.co.in'+"/"+loginData);
                                                    }
                                                });
                                            }

                                            // Show Country Code
//            function showCountryCode(countryMobileCode){
//                if(countryMobileCode != ""){
//                    var countryValueArr = countryMobileCode.split("|");
//
//                    if(countryValueArr[1] != ''){
//                       // alert(countryValueArr[1]);
//                        document.index.countryCode.value = countryValueArr[1];
//                    }else{
//                        document.index.countryCode.value = '+';
//                    }
//                }else{
//                    document.index.countryCode.value = '+';
//                }
//            }
$(document).ready(function(){
	
	$("#SWIFTCode").change(function(){
		ifsccode  = $(this).val();
		$.get("https://ifsc.razorpay.com/"+ifsccode, function(data, status){
		if (status == 'success'){
			
        if (data)
		{	$("#bankName").val(data.BANK);
			$("#branchName").val(data.BRANCH);
		}else
		{
			$("#bankName").val('');
			$("#branchName").val('');
		}
		}else
		{
			$("#bankName").val('');
			$("#branchName").val('');
		}
    }).fail(function(){ 
  		$("#bankName").val('');
			$("#branchName").val('');
	
});
	});
});
        </script>

</body>
</html>
